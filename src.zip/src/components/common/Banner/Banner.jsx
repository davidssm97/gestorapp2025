import './Banner.css'
export function Banner(){

    return(

        <>
            <section className="banner">
                <h2 className='text-white'>
                    <span className="display-1">GestorApp</span>
                    Aplicación para gestión de espacios en tu lugar
                    de descanso...
                </h2>

            </section>
        </>
    )

}