export function Acerca(){
    return(

        <section className="container my-5">
            <section className="row">
                <section className="col-12 col-md-6">
                    <img src="../../../../src/assets/img/BD-1_AG.webp" alt="imagen" className="img-fluid"/>
                </section>
                <section className="col-12 col-md-6">
                    <h2>GestorApp</h2>
                    <p>
                        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Minima ipsa corporis cum accusantium, fuga ab eveniet reiciendis in culpa expedita necessitatibus nihil quaerat accusamus ullam aperiam illo adipisci sequi porro.
                    </p>
                </section>
            </section>
        </section>
    )
}